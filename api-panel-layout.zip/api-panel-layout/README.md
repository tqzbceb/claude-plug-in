# api-panel-layout

TauriTavern / SillyTavern 扩展：把「API 连接配置」面板压到最小，面向**用连接配置（API 预设）切换 API** 的用法。

面板变成这样：

```
API                     [Chat Completion ▾]
Chat Completion Source  [Custom ▾]
当前API预设              [我的API-1 ▾][新建][删除]
预设名称                 [起个名字，新建时自动填进命名弹窗]
端点（基础URL）           [https://.../v1]
API密钥                  [••••••••••••••••] [👁]  ← 点眼睛看明文
模型名                   [gpt-4o]
模型列表                 [gpt-4o ▾]              ← 加载出模型后才出现
                        [加载模型][保存预设][附加参数]
```

平时只用「当前API预设」那一行切换 API，下面那些字段是新建 / 改 API 时用的（默认全部常显，不折叠；想折叠可在设置里打开）。

### 插件只接管四个「自定义」来源，别的一概不动

能存多个 API 的只有这四个 **Chat Completion Source**：

- Custom (OpenAI-compatible) / 自定义（兼容 OpenAI）
- Custom (OpenAI Responses) / 自定义（OpenAI 响应）
- Custom (Claude Messages) / 自定义（Claude 消息）
- Custom (Gemini Interactions) / 自定义（Gemini 交互）

只有它们能填自己的端点，也就是能接中转站，所以才需要存多份。

**除这四个之外，插件不改任何东西**：别的 22 个聊天补全来源（OpenAI、Claude、Google、
OpenRouter、DeepSeek…），以及**文本补全 / NovelAI / AI Horde / KoboldAI Classic**
这些 API 类型，界面**和 TauriTavern 原版逐字符一致** —— 不搬字段、不隐藏任何东西、
不改任何标签，只叠加美化（统一高度 / 宽度 / 间距 / 对齐）。比如 Claude：

```
API                     [Chat Completion ▾]
Chat Completion Source  [Claude ▾]
API密钥                  [••••••••••••] [👁]
模型列表                 [claude-opus-4-7 ▾]
Reverse Proxy           ▾
                        [加载模型][Cancel]
```

字段等宽等高、间距统一、左边缘对齐，和上面那套一个节奏。文本补全那边同理：
「连接配置」「API」「API Type」「API key」「Server URL」全是原生的位置和文案，
只是控件从 24~25px 长到 34px、图标按钮变成 34×34 正方形、Connect/Cancel 30px。

这条可以在设置里关掉（「只接管四个「自定义」来源」），关掉后所有聊天补全来源都走完整重排。

顺手清掉的东西：

- 端点下面的「自定义端点预览 / 不行？在 URL 末尾添加 /v1 试试」新手提示
- API 密钥右边的「管理 API 密钥」小钥匙按钮（用预设保存密钥就不需要它）
- 密钥下面的隐私提示
- **「发送测试信号」（Test Message）按钮** —— 它会真的发一次请求花掉额度，默认隐藏
- 连接配置那排里的**详情 / 改名 / 重载**三颗按钮（只隐藏，不删；设置里能放回来）
- 模型列表在没加载出模型前不显示

挪了位置的东西：

- 连接配置的**保存**（`#update_connection_profile`）从预设那排挪到「加载模型」和「附加参数」之间，
  改名叫**保存预设**。按钮还是原生那颗，逻辑没动。
- 于是「当前API预设」右边只剩两颗：左**新建**、右**删除**。

加上的东西：

- **预设名称**输入框（在「当前API预设」和「端点」之间）：填好名字后点「新建」，
  客户端弹出的命名框会自动填成这个名字，不用再手打。留空就用客户端的默认建议名。

- 密钥框的占位提示 `sk-...`（跟端点框一样有个小虚字）；客户端自己往 placeholder 写东西时不覆盖。
- 密钥框右边的**小眼睛**：原生密钥框是明文 `type="text"`，本插件默认把它遮成圆点，点眼睛看明文，再点遮回去。
  框里是空的（客户端存下密钥后会清空输入框）时，点眼睛直接打开原生的「查看隐藏的 API 密钥」弹窗。

「当前API预设」用的就是原生 connection-manager 那一整块（下拉框 + 6 个按钮），只是搬到了 API 类型下面，逻辑一行没改：填端点和 key → 加载模型 → 选模型 → 点「新建」存成一个预设，以后直接在下拉框里切。

## 安装

仓库根目录**就是**扩展目录（`manifest.json` + `index.js` + `style.css`），三种装法任选：

**方式 A：应用内用 Git URL 安装**（不用下载文件）

```
https://github.com/tqzbceb/claude-plug-in
```

**方式 B：手动放目录**

新建 `data/default-user/extensions/api-panel-layout/`，把 `manifest.json`、`index.js`、`style.css` 三个文件放进去，刷新前端。

**方式 C：zip**

如果客户端有「从 zip 安装扩展」入口，用仓库里的 `api-panel-layout.zip`。

## 设置

装好后「扩展」面板里出现 **API 面板重排**：

| 开关 | 作用 |
| --- | --- |
| 启用重排 | 关掉即完全还原原生面板 |
| 把端点/密钥/模型折叠起来 | 默认关（字段常显）；打开则收进「新建 / 编辑 API」折叠区 |
| 使用中文标签 | 关掉则保留原生英文标签 |
| 隐藏新手提示与管理密钥按钮 | 关掉则提示与小钥匙都回来 |
| 隐藏「发送测试信号」按钮 | 默认开；关掉它才会回来 |
| 密钥框加「小眼睛」查看明文 | 默认开；关掉则密钥框恢复原生明文显示 |
| 连接配置只留新建/删除（保存挪到按钮行） | 默认开；关掉则详情/改名/重载/保存全部回到原位 |
| 显示「预设名称」输入框 | 默认开 |
| 只接管四个「自定义」来源（其余只做美化） | 默认开；关掉则所有聊天补全来源都走完整重排 |
| 模型列表加载后再显示 | 关掉则模型列表一直显示 |
| 各家额外字段也收进面板 | 默认开（只对被接管的来源有意义） |
| 调试日志 | 打印找不到的选择器，排障用 |

打开折叠时，展开状态会被记住。

## 尺寸体系（手机友好 + 视觉统一）

装配时给整个 API 抽屉 `#rm_api_block` 加一个 `.ttal-panel` 类，尺寸规则挂在它下面，
所以**面板里所有单行控件**都是同一档，不只是本插件搬过来的那些：

| 元素 | 高度 |
| --- | --- |
| 输入框 / 下拉框（API、Chat Completion Source、预设、预设名称、端点、密钥、模型名、模型列表、Prompt Post-Processing） | `2.25 × 主题字号` ≈ 34px |
| 图标按钮（新建 / 删除 / 小眼睛） | 同上，且是**正方形** 34×34 |
| 按钮行（加载模型 / 保存预设 / 附加参数） | `2 ×` ≈ 30px，比输入框矮一档但不扁 |

- 宽度全部撑满面板，每一行的总宽一致（图标按钮那行也算进去）。
- **间距只有两个值**：标签到自己的控件 `4px`，组与组之间 `12px`；
  按钮行没有标签，上下各多留 4px（16px）免得挤在两组中间。
  原生这块本来是混着来的（有的标签贴着控件 0px、有的隔 10px，组间 5 / 12 / 17 / 20px 都有），
  统一的做法是：所有控件外边距清零、间距只由标签的外边距和 `#ttal_root` 的 gap 两处决定，
  并顺手掐掉三个隐形的加数（外层容器自带的 `gap:5px`、折叠区的 `padding-top`、
  「详情」空容器占掉的一个 gap）。
- 标签统一到同一字号（原生「当前API预设」是 h3、比别的大一号，这里降到同档）。
- 左边缘全部对齐到同一条线：标签、输入框、按钮、状态圆点、「自动连接」勾选框
  （原生勾选框往里缩了 4px，状态行也差一截）。
- 所有下拉框右侧统一画一个小箭头，提示这里能点开（原生那个箭头图片在有些皮肤下看不见）。
- 高度按 `--mainFontSize` 算，主题字号改了会整体跟着缩放。
- `.ttal-panel` 用 `classList` 加、卸载时移除，不记录旧 class —— 因为客户端会不停改
  `#rm_api_block` 的 `closedDrawer/openDrawer`，记录再还原会把抽屉状态弄坏。

## 设计原则

1. 只 **移动**（move）原生节点，绝不 clone —— 原生 jQuery 事件绑定全部保留，底层逻辑零改动。
2. 完全可逆：搬走的节点在原位留注释锚点，隐藏与改字单独记账；关掉扩展时 DOM 逐字符还原。
3. 不注入任何颜色 / 字体 / 圆角 / 阴影，只用原生 class，主题美化与第三方扩展不冲突。
4. 找不到某个原生元素时只隐藏该字段并打日志，绝不抛错、绝不破坏面板。

## 兼容性

按 TauriTavern v1.6.5 的真实 DOM 编写（`src/index.html` + `scripts/extensions/connection-manager/settings.html`）。
各 source 的字段选择器集中在 `index.js` 的 `SOURCE_FIELDS`，未列出的 source 按 `#api_key_<source>` / `#model_<source>_select` 惯例推导。

某个字段没出现时：打开**调试日志**，控制台会打印 `[api-panel-layout]` 找不到的选择器，改 `SOURCE_FIELDS` 即可。

排障入口（浏览器控制台）：

```js
apiPanelLayout.apply()     // 手动重排
apiPanelLayout.teardown()  // 完全还原
apiPanelLayout.cfg()       // 当前设置
```

## 测试状态

在按 v1.6.5 真实 DOM 拼出的替身页面上验证通过：

- 「当前API预设」是原生连接配置块且排在第一位，6 个按钮点击后原生处理器照常触发
- 折叠区默认收起、状态被记住
- 新手提示 / 隐私提示 / 小钥匙 三者 `display: none`
- 点「加载模型」拿到模型后模型列表才出现
- custom ↔ claude 切换后，上一个 source 的字段全部归位
- `teardown()` 后 `#rm_api_block` 与加载前**逐字符一致**
- 重复 `apply()` 不堆积节点（44 → 44）

在真实 markup + 真实 CSS 的预览页上另外验证通过（v2.0.1）：

- 连续多次 `apply()` 后布局稳定，不会出现空标签（修掉了 `closest('.wide100p')` 命中输入框自身的 bug）
- 多次 `apply()` 再 `teardown()`，`#rm_api_block` 仍与加载前逐字符一致
- `#test_api_button` 被隐藏，且 `teardown()` 后原样恢复
- 小眼睛：默认遮成 `password`，点击切明文、再点遮回，切换 source 后新密钥框自动重新遮上；
  `teardown()` 后密钥框恢复原生 `type="text"`，眼睛节点从 DOM 里摘掉
- 小眼睛与密钥框**严格等高**（抄输入框的上下 margin + 行内拉伸），宽度与原生那颗小钥匙一致
- 预设那排只剩 `connection_profiles, create, delete`；按钮行为
  `加载模型, (Cancel), 保存预设, 附加参数`；连续 3 次装配结果不变
- 「预设名称」有内容时点「新建」，命名弹窗的输入框被自动填好
- `teardown()` 后：预设名称框和眼睛都摘掉、保存按钮回到预设行、详情按钮恢复可见，`#rm_api_block` 逐字符一致
- 尺寸实测：API / Chat Completion Source / 预设 / 预设名称 / 端点 / 密钥 / 模型名 / 模型列表 /
  Prompt Post-Processing 全部 34px 等高等宽；新建、删除、小眼睛都是 34×34 正方形；按钮行 30px
- 间距实测：整块面板从上到下只有 4 / 12 两种间隙，按钮行上下 16
- 左边缘实测：端点框、标签、加载模型、状态圆点、勾选框 left 完全相同
- 关掉插件后：`.ttal-panel` 移除，控件回到原生 24~25px、间距回到原生 10px，`#rm_api_block` 逐字符一致

v2.5.0 另外修掉两个真问题，都在预览页上验过：

- **主 API 切到 Text Completion 时不再丢「当前API预设」**。客户端切走 Chat Completion 时会把整个
  `#openai_api` 藏起来，而连接配置原本挂在 `#rm_api_block` 顶部、对所有 API 都可见 ——
  被搬进去就跟着一起消失了。现在这种情况下插件自动**完整还原**，预设块回到原位第一格照常可用，
  切回 Chat Completion 再自动重新装配（实测：切走后 `#rm_api_block` 与加载前逐字符一致，切回后重新装配）。
- **不再往原生节点上留任何痕迹**。原先「保存预设」的 class 每次 `apply()` 都会重复追加一遍
  （越跑越长），另外两处 `data-ttal-*` 标记属性 `teardown()` 时没清掉、加的监听也没解绑。
  现在补 class 是幂等的，监听走可解绑的登记表（实测：开→关 5 轮，每轮 `teardown()` 后
  `#rm_api_block` 都与加载前**逐字符一致**，残留 `data-ttal-*` 为 0；连续 `apply()` 3 次装配态不变）。

v2.6.0 的改动，逐个 source 实测过（预览页里把 26 个 Chat Completion Source 全走了一遍）：

- **API 预设只留给四个「自定义」来源**：其余 22 个来源下，「当前API预设」整块（含下拉框、
  新建、删除）放回原位并隐藏，「预设名称」和「保存预设」也不出现；按钮行只剩原生的
  加载模型 / Cancel（+ 各家自己的按钮）。
- **别家的模型下拉框现在也统一了尺寸**。它们是裸 `<select>`（没有 `text_pole` class），
  之前漏在尺寸规则外，只有 24px 高，比输入框矮一截。OpenRouter 的服务商 / 量化那两个
  多行列表框按原样保留（本来就是多行的）。
- **不再出现两个标题**。别家的模型字段结构是 `<div><h4>Claude Model</h4><select></div>`，
  标签在容器里面，之前没认出来，于是我们在外面又造了一个「模型列表」。现在原地改字。
- **「反向代理」折叠抽屉不再被拆散**。它的 `[data-source]` 就打在 `.inline-drawer` 上，
  之前按子节点搬会把 toggle 和 content 拆成兄弟，客户端的 `closest('.inline-drawer')`
  找不到祖先，**点了展不开**。现在这种自成一体的容器整块搬。
- **Vertex AI 的 Express 模式**：密钥 / Project ID / 服务账号 JSON 三个框之前被挤成 134px 宽，
  现在拉满整宽；「验证 JSON」按钮和按钮行同高；Express 模式那个第二密钥框旁边的小钥匙也隐藏了。
- 26 个来源逐一实测：单行控件全部 34px 等高、按钮 30px、没有重复标题、没有被拆散的抽屉。
- 逛完全部 26 个来源再回到 custom、连续 `apply()` 3 次：装配态逐字符不变；
  关掉插件后 `#rm_api_block` 与加载前**逐字符一致**（连开关 3 轮都一致）。

v3.0.0 把边界收紧成一条规则：**插件只碰四个「自定义」来源，别的只叠加 CSS 美化**。

- 删掉了「API 只留文本补全 / 聊天补全」这个开关 —— 它会把 NovelAI / AI Horde / KoboldAI
  从 API 下拉里藏起来，属于改动原版，不该做。现在 API 下拉是原样的 5 项。
- 非自定义来源不再隐藏原生的「连接配置」块，也不再隐藏「发送测试信号」、不再动小钥匙和提示。
  这些来源下插件对 DOM 的改动是**零**。
- 美化（`.ttal-panel`）现在覆盖到所有 API 类型，文本补全 / NovelAI / AI Horde / KoboldAI
  也跟着统一尺寸；只在被接管时才额外加 `.ttal-managed`（几条只对重排版式成立的规则挂在它上面）。

验收方式是**逐字符比对**：预览页在插件加载前存一份 `#rm_api_block` 的原始 innerHTML，
遍历所有状态后逐一比对（实测全部通过）：

- 22 个非自定义聊天补全来源：DOM 与原版逐字符一致
- 文本补全 / NovelAI / AI Horde / KoboldAI Classic 四个 API 类型：逐字符一致
- 文本补全下 15 个 API Type（Aphrodite、DreamGen、Featherless、Generic、HuggingFace、
  InfermaticAI、KoboldCpp、llama.cpp、Mancer、Ollama、OpenRouter、TabbyAPI、
  Text Generation WebUI、TogetherAI、vLLM）：逐字符一致
- 四个自定义来源：正常接管，连续 `apply()` 3 次装配态不变
- 在上述状态之间乱切一通后关掉插件：`#rm_api_block` 与加载前逐字符一致，`.ttal-panel` 也摘除

未在真机 TauriTavern 上跑过。
